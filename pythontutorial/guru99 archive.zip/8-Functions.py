#Function

def func1():
    print('I am learning python  function')

func1()

#Square
def square(x):
    y=0
    y = x*x
    print('Square : ',y)

square (3)

#Square with return value

def square(x):
    y=0
    y=x*x
    return y

z=square(4)
print('Square:Return Value', z)

#Function Arguments

def multiply(num1,num2):
    print(' num1 :', num1, ' num2 :', num2)
    return num1*num2
product = multiply(10,12)
print('product : ',product)


product = multiply(num2=10,num1=15)
print('product : ',product)


#Function with multiple arguments
def multiple(*args):
    print(args)

multiple(1,3,4,5,7,9,10)

