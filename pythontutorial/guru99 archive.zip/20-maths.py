# Square root calculation
import math
print('sqrt ', math.sqrt(4))
#power
print('power ',math.pow(2,3))
#absolute value
print('absolute value', math.fabs(-10))
#Ceil
x = 16.4
print('ceil ',math.ceil(x))
#Floor
print('Floor ',math.floor(x))
#Factorial
print('Factorial ',math.factorial(4))
# Remainder
print('remainder ',math.fmod(10, 5))
#Not a number
print('Is a number ',math.isnan(18))
# pi value
print('value of pi', math.pi)


#random number generator
import random
print('random number  ', random.randint(10,20))

print('random number 1', random.random())

