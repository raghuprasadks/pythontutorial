class Animal:
    def eat(self):
        print('Eating')
class Dog(Animal):
    def bark(self):
        print('Barking')
d= Dog()
d.eat()
d.bark()
#Multi level
class Animal:
    def eat(self):
        print('Eating')
class Dog(Animal):
    def bark(self):
        print('Barking')
class BabyDog(Dog):
    def weep(self):
        print('Weeping ')
d= BabyDog()
d.eat()
d.bark()
d.weep()

# Multiple Inheritance
class First(object):
    def __init__(self):
        super(First,self).__init__()
        print("first")
class Second(object):
    def __init__(self):
        super(Second,self).__init__()
        print("second")
class Third(Second,First):
    def __init__(self):
        super(Third,self).__init__()
        print("Third")

Third()

#Method overloading
class Human:
    def sayHello(self, name=None):
        if name is not None:
            print('Hello ' + name)
        else:
            print('Hello ')
# Create instance
obj = Human()
# Call the method
obj.sayHello()
# Call the method with a parameter
obj.sayHello('To Python')

# Method Overriding
class Base(): # Base class
    '''def add(self,a,b):
        s=a+b
        print s'''
    def add(self,a,b,c):
        self.a=a
        self.b=b
        self.c=c
        sum =a+b+c
        print(sum)
class Derived(Base): # Derived class
    def add(self,a,b): # overriding method
        sum=a+b
        print(sum)
add_fun_1=Base() #instance creation for Base class
add_fun_2=Derived()#instance creation for Derived class

add_fun_1.add(4,2,5) # function with 3 arguments
add_fun_2.add(4,2)   # function with 2 arguments

#Overloading 3.2.1
class A:

    def overload(*functions):
        return lambda *args, **kwargs: functions[len(args)](*args, **kwargs)
    stackoverflow=overload(                    \
        None, \
        #there is always a self argument, so this should never get called
        lambda self: print('First method'),      \
        lambda self, i: print('Second method', i) \
    )
