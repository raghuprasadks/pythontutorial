#IF

def main():
    x,y=2,8
    if(y>x):
        print ('Y is Greater ',y)

if(__name__=="__main__"):
    main()
#Else

def main():
    x,y=10,8
    if(y>x):
        print ('Y is Greater ',y)
    else:
        print('X is Greater ', x)
if(__name__=="__main__"):
    main()

#Else both number is same

def main():
    x,y=10,10
    if(y>x):
        print ('Y is Greater ',y)
    else:
        print('X is Greater ', x)
if(__name__=="__main__"):
    main()

#elif

def main():
    total = 100
    country = "US"
    #country = "AU"
    if country == "US":
        if total <= 50:
            print("Shipping Cost is  $50")
        elif total <= 100:
            print("Shipping Cost is $25")
        elif total <= 150:
            print("Shipping Costs $5")
    else:
        print("FREE")
    if country == "AU":
        if total <= 50:
                print("Shipping Cost is  $100")
        else:
            print("FREE")
if(__name__=="__main__"):
    main()
