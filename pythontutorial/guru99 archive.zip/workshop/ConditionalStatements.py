#if else
var = 10;
if (var<10):
    print('Value is less than 10')
else:
    print('Value is equal to or more than 10')

#if elif

score = 50;

if (score<50):
    print('score is less than 50')
elif (score > 50):
    print('score is greater than 50')
else:
    print('Score is equal to 50')
