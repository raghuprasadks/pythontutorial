name = input('What is your name ?')
print('Your name is ', name, " type of ", type(name))
age = int(input ('What is your age ?'))
print('Your age is ',age, " type of ", type(age))
