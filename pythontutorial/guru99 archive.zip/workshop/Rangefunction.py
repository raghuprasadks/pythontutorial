#range(stop)
range1 = range(5)
print(range1)

#range(start,stop)
range2 = range(5,10)
print(range2)

#range(start,stop,step)
range3 = range(2,10,2)
print(range3)

#Using in for loop
for i in range1:
    print('range1 ',i)

for i in range2:
    print('range 2 ',i)

for i in range3:
    print('range 3 ',i)
