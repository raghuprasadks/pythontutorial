import sys

print("No of arguments ",len(sys.argv), ' arguments ')
print(" Argument list ",str(sys.argv))