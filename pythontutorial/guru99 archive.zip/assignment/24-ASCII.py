c = input("Enter a character: ")

print("The ASCII value of '" + c + "' is", ord(c))