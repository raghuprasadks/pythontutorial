# Store input numbers:
num1=input('Enter first number:')
num2=input('Enter second number')
# Add two numbers
#sum=float(num1)+float(num2)
sum=int(num1)+int(num2)
#subtract two numbers
sub=float(num1)-float(num2)
#Multiply two numbers
mul=float(num1)*float(num2)
#Divide two numbers
div=float(num1)/float(num2)
#Display the sum
print('The sum of {0} and {1} is {2}'.format(num1,num2,sum))
#Display the subtraction
print('The subtraction of {0} and {1} is {2}'.format(num1,num2,sub))

num3=int(input('Enter first number:'))
num4=int(input('Enter second number'))
sum = num3+num4;
print('sum of int is ', sum)

num5=float(input('Enter first number:'))
num6=float(input('Enter second number'))
sum = num5+num6;
print('sum is : Float sum', sum)
