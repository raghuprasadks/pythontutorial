import random
print(random.randint(100,500))  