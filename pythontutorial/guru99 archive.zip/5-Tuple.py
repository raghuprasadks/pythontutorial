#Tuple
months =('Jan','Feb','Mar','Apr')
print("Tuple months :",months)

numbers =(1,2,3,4,5,6)
print("Tuple numbers :",numbers)

print("Slicing : ",months[0:2])

#Packinng
personalinfo = ('Raghu','Kayshalya.tech','Bengaluru')
#unpacking
(Name,Company,City) =personalinfo
print (Name)
print (Company)
print (City)

#Comparision

a=(5,7)
b= (3,6)
if(a>b):
    print("A is bigger")
else:
    print("B is bigger")

a=(5,6)
b=(5,4)
if (a>b):
    print("a is bigger")
else:
    print("b is bigger")

a=(5,6)
b=(6,4)
if (a>b):
    print("a is bigger")
else:
    print("b is bigger")

a=(5,5)
b=(5,5)
if (a>b):
    print("a is bigger")
else:
    print("b is bigger")

#Tuples and dictionary

a={'X':100,'Y':200}
b=a.items()
print(b)

#Deleting tuple
c=(100,101)
del c
#print(c)

#Max and min
numbers = (10,5,200,7,1,300)
print(max(numbers))

print(min(numbers))

print(sorted(numbers))
print(len(numbers))

