#Dictionary
tele ={'raghu':9845547471,'rakesh':9898989898,'govind':8787676765}

print(tele['rakesh'])

tele ={'raghu':9845547471,'rakesh':9898989898,'govind':8787676765,'raghu':9845547472}
print(tele['raghu'])

#copying
duptele = tele.copy()
print(duptele)

#Update

tele.update({'rakesh':8888888888})
print(tele)

#Delete key

del tele ['rakesh']
print(tele)

#items
print("items %s :",tele.items())
#check for existance of keys
Dict = {'Tim': 18,'Charlie':12,'Tiffany':22,'Robert':25}

Boys = {'Tim': 18,'Charlie':12,'Rakesh':25}

Girls = {'Tiffany':22}

for key in Boys.keys():

    if key in Dict.keys():
        print(True)
    else:
        print(False)


#soring not working
'''
Dict = {'Tim': 18,'Charlie':12,'Tiffany':22,'Robert':25}

Boys = {'Tim': 18,'Charlie':12,'Robert':25}

Girls = {'Tiffany':22}


Students = Dict.keys()
Students.sort()

for S in Students:
      print(":".join((S,str(Dict[S]))))
'''
#Built in function

#len
Dict = {'Tim': 18,'Charlie':12,'Tiffany':22,'Robert':25}
print("Length : %d" % len (Dict))

#variable type

Dict = {'Tim': 18,'Charlie':12,'Tiffany':22,'Robert':25}
print("variable Type: %s" %type (Dict))

#compare cmp() Not working
'''
Boys = {'Tim': 18,'Charlie':12,'Robert':25}
Girls = {'Tiffany':22}
print(cmp(Girls, Boys))
'''

Dict = {'Tim': 18,'Charlie':12,'Tiffany':22,'Robert':25}
print("printable string:%s" % str (Dict))