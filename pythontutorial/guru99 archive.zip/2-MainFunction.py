def main():
    print ('This is from main function')

if(__name__=='__main__'):
    main()
print ('Another statement')


