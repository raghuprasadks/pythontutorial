print ('Hello World.Welcome to Python')
a = 10
b = 20
print(a+b)

#Single line comment

'''
Multi line comment
Line 1
Line 2
Line 3

'''

#identifiers
#valid
name ='raghu'
_fullname ='raghu prasad'
#invalid
#1stname ='raghu'
#__fullName ='ravi'
#@age = 21
#language specific
#__init__

