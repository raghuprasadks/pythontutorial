try:
    a=10/0
    print(a)
except ArithmeticError:
    print("This statement is raising an exception")
else:
    print("No exception proceed")

#Except with no exception

try:
    a=10/0
    print(a)
except:
    print("Exception")
else:
    print("Proceed no exception")

#Declaring multiple exception

try:
    a=10/0
    print(a)
#except ArithmeticError,NameError: - 3.6 does not support
except ZeroDivisionError:
    print("ZeroDivisionError")
else:
    print("Successfully Done")

#Finally Block

try:
    a=10/0;
    print(a)
except ZeroDivisionError:
    print(ZeroDivisionError)
finally:
    print("Finally block is always called")

#Raise an exception

try:
    a=10
    print(a)
    raise NameError("Hello")
except NameError as e:
    print("An exception occured")
    print(e)

#Custom exception

class ErrorInCode(Exception):
    def __init__(self,data):
     self.data = data
    def __str__(self):
        return repr(self.data)
try:
    raise ErrorInCode(2000)
except ErrorInCode as ae:
    print("Received error :",ae.data)

