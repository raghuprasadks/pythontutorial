#DateTime
from datetime import date
from datetime import time
from datetime import datetime
#def main():
 	 ##DATETIME OBJECTS
     #Get today's date from datetime class
    today=datetime.now()
    print(today)
  # Get the current time
    t = datetime.time(datetime.now())
    print("The current time is", t)
 #weekday returns 0 (monday) through 6 (sunday)
    wd = date.weekday(today)
 #Days start at 0 for monday
    days= ["monday","tuesday","wednesday","thursday","friday","saturday","sunday"]
    print("Today is day number %d" % wd)
    print("which is a " + days[wd])

if __name__== "__main__":
    main()

#Formatting Y - Year - four numbers

from datetime import datetime
def main():
    now = datetime.now()
    print(now.strftime("%Y"))

if __name__== "__main__":
    main()

#Formatting y - Year last two numbers

from datetime import datetime
def main():
    now = datetime.now()
    print("Formatting")
    #year in 4 digits 2018
    print(now.strftime("%Y"))
    #year in 2 digits 18
    print(now.strftime("%y"))
    #Day in full for example Friday
    print(now.strftime("%A"))
    #Day in short for example Fri
    print(now.strftime("%a"))
    #Month in Full for example May
    print(now.strftime("%B"))
    # Month in Full for example May
    print(now.strftime("%b"))
    # Day of the month for example 18
    print(now.strftime("%d"))

if __name__== "__main__":
    main()


#
#Example file for formatting time and date output
#
from datetime import datetime
def main():
   #Times and dates can be formatted using a set of predefined string
   #Control codes
      print("Local date time ")
      now= datetime.now() #get the current date and time
      #%c - local date and time, %x-local's date, %X- local's time
      print(now.strftime("%c"))
      print(now.strftime("%x"))
      print(now.strftime("%X"))
##### Time Formatting ####
      #%I/%H - 12/24 Hour, %M - minute, %S - second, %p - local's AM/PM
      print(now.strftime("%I:%M:%S %p")) # 12-Hour:Minute:Second:AM
      print(now.strftime("%H:%M")) # 24-Hour:Minute

if __name__== "__main__":
    main()

#
#Example file for working with timedelta objects
#
from datetime import date
from datetime import time
from datetime import datetime
from datetime import timedelta
# construct a basic timedelta and print it
print(timedelta(days=365,hours=8,minutes=15))
# print today's date
print("today is: " + str(datetime.now()))
# print today's date one year from now
print("one year from now it will be:" + str(datetime.now() + timedelta (days=365)))
#create a timedelta that uses more than one argument
#print "in one week and 4 days it will be " + str(datetime.now() + timedelta(weeks=1, days=4))
#How many days until New Year's Day?
today= date.today() #get todays date
nyd= date(today.year,1,1) #get New Year Day for the same year
#use date comparison to see if New Year Day has already gone for this year
#if it has, use the replace() function to get the date for next year
if nyd < today:
    print("New Year day is already went by %d days ago" % ((today-nyd).days))
